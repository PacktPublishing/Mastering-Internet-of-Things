﻿CSS: Main.css
Icon: /favicon.ico

<header id="header">
<nav>

* [Momentary](/Index.md)
* [History](/History.md)
* [%Title]
* [Mastering IoT](https://github.com/PeterWaher/MIoT)
* [IoT Gateway](https://github.com/PeterWaher/IoTGateway)

</nav>
</header>
<main>

[%Details]

</main>

<footer>
This application is part of the [Mastering Internet of Things](https://github.com/PeterWaher/MIoT) book.
</footer>

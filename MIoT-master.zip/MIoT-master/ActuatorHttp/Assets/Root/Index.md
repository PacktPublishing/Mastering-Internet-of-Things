﻿Title: Actuator
Author: Peter Waher
Description: This page displays the current state of the actuator.
Cache-Control: max-age=0, no-cache, no-store
Javascript: ToggleOutput.js
Master: Menu.md
UserVariable: User
Login: Login.md

Current state
============================

Output is currently turned **<span id='OutputState'>{ActuatorHttp.App.Output}</span>**

<button onclick='ToggleOutput();'>Toggle Output</button>
